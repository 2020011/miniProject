package miniproject_2;

public class EndAction implements Action {
	private int money;

	public void execute(UI ui) {
		((CUI) ui).show_change(this.money);

	}

	public void set_money(int money) {
		this.money = money;
	}

}
