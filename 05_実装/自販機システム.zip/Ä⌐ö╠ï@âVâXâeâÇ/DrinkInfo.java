package miniproject_2;

import java.util.ArrayList;
import java.util.List;

public class DrinkInfo {
	private List<Drink> drinkinfo;

	DrinkInfo() {
		drinkinfo = new ArrayList<>();
		Drink drink1 = new Drink(1, "コカ・コーラ　 ", 150, 50);
		Drink drink2 = new Drink(2, "ポカリスエット", 160, 100);
		Drink drink3 = new Drink(3, "お茶　　　　  ", 120, 100);
		drinkinfo.add(drink1);
		drinkinfo.add(drink2);
		drinkinfo.add(drink3);
	}

	public List<Drink> get_drinkInfoList() {
		return this.drinkinfo;
	}

	public Drink get_drinkInfo(int drink_num) {
		Drink drink = null;
		for (int i = 0; i < drinkinfo.size(); i++) {
			if (drinkinfo.get(i).get_num() == drink_num) {
				drink = drinkinfo.get(i);
			}
		}
		return drink;
	}

}
