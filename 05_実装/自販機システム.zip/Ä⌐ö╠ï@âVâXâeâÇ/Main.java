package miniproject_2;

public class Main {
	public static void main(String[] args) {
		
		DrinkInfo drinkinfo = new DrinkInfo();
		UI ui = new CUI();
		MoneyAction m_action = new MoneyAction();
		BuyAction b_action = new BuyAction();
		EndAction e_action = new EndAction();
		
		VendingMachine vend =
				new VendingMachine(drinkinfo,ui,m_action,b_action,e_action);
		vend.start();
	}
}
