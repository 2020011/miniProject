package miniproject_2;

import java.util.List;
import java.util.Scanner;

public class CUI extends UI{
	
	public CUI() {
		super();
	}
	
	//飲み物番号入力
	@Override
	public int input_drink_num() {
		int drink_num = 0;
		System.out.println("飲み物の番号を入力してください");
		Scanner scan = new Scanner(System.in);
		try {
			drink_num = scan.nextInt();	
		}catch(Exception e) {
			return -1;
		}
		return drink_num;
	}

	//金額入力
	@Override
	public int input_money_num() {
		int money_num = 0;
		System.out.println("投入する金額の番号を入力してください");
		Scanner scan = new Scanner(System.in);
		try {
			money_num = scan.nextInt();	
		}catch(Exception e) {
			return -1;
		}
		return money_num;
	}
	
	//枚数入力
	@Override
	public int input_money_count() {
		int money_count = 0;
		System.out.println("投入する枚数を入力してください");
		Scanner scan = new Scanner(System.in);
		try {
			money_count = scan.nextInt();
		}catch(Exception e) {
			return -1;
		}
		return money_count;
	}

	//メニュー番号を入力
	@Override
	public int input_menu_num() {
		int menu_num = 0;
		System.out.println("メニュー番号を入力してください");
		Scanner scan = new Scanner(System.in);
		try {
			menu_num = scan.nextInt();	
		}catch(Exception e) {
			return -1;
		}
		return menu_num;
	}
	
	//金額表示
	public void show_money_menu() {
		System.out.println("1:10円");
		System.out.println("2:50円");
		System.out.println("3:100円");
		System.out.println("4:500円");
		System.out.println("5:1000円");
	}
	
	//メニュー表示
	public void show_menu() {
		System.out.println("<メニュ―>");
		System.out.println("1:お金追加");
		System.out.println("2:購入");
		System.out.println("3:買わない");
	}
	
	//お釣り表示
	public void show_change(int money) {
		System.out.println("おつり:" +money);
	}
	
	//商品表示
	public void show_drink_menu(List<Drink> drinkInfo) {
		System.out.println("　商品番号　|　　　商品名　　　|　価格　|");
		System.out.println("------------------------------");
		for (int i = 0; i < drinkInfo.size(); i++) {
            int num = drinkInfo.get(i).get_num();
            String name = drinkInfo.get(i).get_name();
            int price = drinkInfo.get(i).get_price();
            System.out.println("　　　"+num+"　　　　　　　"+ name+"　　　"+ price);
        	}
	}
	
	//購入商品表示
	public void show_buy_result(String name) {
		System.out.println("購入品:" +name);
	}
	
	//投入金額の合計を表示
	public void show_money_result(int money) {
		System.out.println("合計金額:" +money);
	}

}
