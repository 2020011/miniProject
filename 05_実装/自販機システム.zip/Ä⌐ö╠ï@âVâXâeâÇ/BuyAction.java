package miniproject_2;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;


public class BuyAction implements Action{
	
	private int money = 0;
	private DrinkInfo drink_info;
	private boolean buy_flag = false;
	
	public BuyAction() {
		this.drink_info = new DrinkInfo();
	}
	
	@Override
	public void execute(UI ui) {
		int drink_num = 0;
		Drink drink;
		List<Drink> drink_list = drink_info.get_drinkInfoList();
		((CUI) ui).show_drink_menu(drink_list);
		drink_num = ((CUI) ui).input_drink_num();
		drink = this.drink_info.get_drinkInfo(drink_num);
		
		if(Objects.isNull(drink)) {
			System.out.println("存在しません");
		}
		else {
			if(drink.get_price() > this.money) {
				System.out.println("投入金額が不足しています");
			}
			else {
				((CUI) ui).show_buy_result(drink.get_name());
				this.buy_flag = true;
				this.money = this.money - drink.get_price();
			}
		}
		
	}
	
	public void set_money(int money) {
		this.money = money;
	}
	
	public int get_money() {
		return this.money;
	}
	
	public boolean get_result() {
		return this.buy_flag;
	}

}
