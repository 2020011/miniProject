package miniproject_2;

public abstract class  UI {
	public UI() {
		
	}
	
	abstract int input_drink_num();
	abstract int input_money_num();
	abstract int input_money_count();
	abstract int input_menu_num();
	
}
