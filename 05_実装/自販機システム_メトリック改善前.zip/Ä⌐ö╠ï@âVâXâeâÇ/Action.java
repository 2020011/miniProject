package miniproject_2;

interface Action {
	void execute(UI ui);
}
