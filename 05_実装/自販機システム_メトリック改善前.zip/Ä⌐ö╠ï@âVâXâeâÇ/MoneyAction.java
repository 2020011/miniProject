package miniproject_2;

public class MoneyAction {

	private int money;

	public void execute(UI ui) {
		((CUI) ui).show_money_menu();
		int x = 0;
		int price = 0;
		while (x != 1 && x != 2 && x != 3 && x != 4 && x != 5) {
			x = ((CUI) ui).input_money_num();
			price = 0;
			if (x == 1) {
				price = 10;
			} else if (x == 2) {
				price = 50;
			} else if (x == 3) {
				price = 100;
			} else if (x == 4) {
				price = 500;
			} else if (x == 5) {
				price = 1000;
			}

			if (x != 1 && x != 2 && x != 3 && x != 4 && x != 5) {
				System.out.println("1~5の値を入力してください");
			}
		}
		int y = 0;
		while (y <= 0) {
			y = ((CUI) ui).input_money_count();
			if (y <= 0) {
				System.out.println("1以上の数字を入力してください");
			}
		}
		money += price * y;
		((CUI) ui).show_money_result(this.money);

	}

	public int get_money() {
		return this.money;
	}

}
