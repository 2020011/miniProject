package miniproject_2;

import java.util.List;

public class VendingMachine {
	private DrinkInfo drinkinfo;
	private UI ui;
	private int money;
	private MoneyAction m_action;
	private BuyAction b_action;
	private EndAction e_action;

	public VendingMachine(DrinkInfo drinkinfo, UI ui, MoneyAction m_action, BuyAction b_action, EndAction e_action) {
		this.drinkinfo = drinkinfo;
		this.ui = ui;
		this.m_action = m_action;
		this.b_action = b_action;
		this.e_action = e_action;

	}

	public void start() {
		List<Drink> drinkinfolist = drinkinfo.get_drinkInfoList();
		((CUI) ui).show_drink_menu(drinkinfolist);

		boolean bought = false;
		int menu_num = 0;
		while (menu_num != 3 && bought == false) {
			((CUI) ui).show_menu();

			menu_num = ((CUI) ui).input_menu_num();

			if (menu_num == 1) {
				m_action.execute((CUI) ui);
				this.money = m_action.get_money();

			} else if (menu_num == 2) {
				b_action.set_money(money);
				b_action.execute((CUI) ui);
				money = b_action.get_money();
				bought = b_action.get_result();
			} else if (menu_num == 3) {
				
			}
			else {
				System.out.println("1～3の番号を入力してください");
			}

		}

		e_action.set_money(money);
		e_action.execute((CUI) ui);

	}
}
