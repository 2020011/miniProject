package miniproject_2;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

public class MoneyActionTest {

	@Test
	public void テストケース3_1() {
		// 事前準備
		UI ui = new CUI();
		MoneyAction act = new MoneyAction();
		act.execute(ui);

		// ByteArrayOutputStream out = new ByteArrayOutputStream();
		// System.setOut(new PrintStream(out));
		// act.execute(ui);
		int i = act.get_money();

		// 検証
		// assertThat(1, is(1));
		assertThat(i, is(200));

	}

}
