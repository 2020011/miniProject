package miniproject_2;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.junit.Before;
import org.junit.Test;

import java.util.*;

public class BuyActionTest {
	
	BuyAction buy;
	CUI ui;
	
	@Before
	public void setup() {
		//drink_info = new DrinkInfo();
		ui = new CUI();
	}	
	
	@Test
	public void test1_1() {
		DrinkInfo drink_info = new DrinkInfo();
		buy = new BuyAction();

		buy.set_money(200);
		buy.execute(ui);
		
		assertThat(buy.get_result(),is(true));
		assertThat(buy.get_money(),is(50));
	}
	
	@Test
	public void test2_1() {
		DrinkInfo drink_info = new DrinkInfo();
		buy = new BuyAction();

		buy.set_money(200);
		buy.execute(ui);
		
		assertThat(buy.get_result(),is(false));
		assertThat(buy.get_money(),is(200));
	}
	
	@Test
	public void test2_2() {
		DrinkInfo drink_info = new DrinkInfo();
		buy = new BuyAction();

		buy.set_money(100);
		buy.execute(ui);
		
		assertThat(buy.get_result(),is(false));
		assertThat(buy.get_money(),is(100));
	}
	
}
