package miniproject_2;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.Test;

public class EndActionTest {

	@Test
	public void テストケース1() {
		// 事前準備
		UI ui = new CUI();
		EndAction act = new EndAction();
		act.set_money(200);
		act.execute(ui);

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		System.setOut(new PrintStream(out));
		act.execute(ui);

		// 検証
		// assertThat(1, is(1));
		assertThat(out.toString(), is("おつり:200" + System.lineSeparator()));

	}

}
