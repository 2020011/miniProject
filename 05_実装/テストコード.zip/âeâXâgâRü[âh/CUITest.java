package miniproject_2;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.junit.Before;
import org.junit.Test;


public class CUITest {
	CUI cui;
	
	@Before
	public void setup() {
		cui = new CUI();
	}
	
	@Test
	public void test1_1() {
		int num = cui.input_drink_num();
		assertThat(num,is(0));
	}
	
	@Test
	public void test1_2() {
		int num = cui.input_drink_num();
		assertThat(num,is(1));
	}

	@Test
	public void test1_3() {
		int num = cui.input_drink_num();
		assertThat(num,is(-1));
	}
	
	@Test
	public void test2_1() {
		int num = cui.input_money_num();
		assertThat(num,is(0));
	}
	
	@Test
	public void test2_2() {
		int num = cui.input_money_num();
		assertThat(num,is(1));
	}
	
	@Test
	public void test2_3() {
		int num = cui.input_money_num();
		assertThat(num,is(-1));
	}
	
	@Test
	public void test3_1() {
		int num = cui.input_money_count();
		assertThat(num,is(0));
	}
	
	@Test
	public void test3_2() {
		int num = cui.input_money_count();
		assertThat(num,is(1));
	}
	
	@Test
	public void test3_3() {
		int num = cui.input_money_count();
		assertThat(num,is(-1));
	}
	
	@Test
	public void test4_1() {
		int num = cui.input_menu_num();
		assertThat(num,is(0));
	}
	
	@Test
	public void test4_2() {
		int num = cui.input_menu_num();
		assertThat(num,is(1));
	}

	@Test
	public void test4_3() {
		int num = cui.input_menu_num();
		assertThat(num,is(-1));
	}

	
}
